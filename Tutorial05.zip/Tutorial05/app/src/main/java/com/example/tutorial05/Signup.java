package com.example.tutorial05;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class Signup extends AppCompatActivity {
    EditText fname,lname,email,password;
    RadioGroup gender;
    RadioButton Gender;
    Button signup;
    Switch branch;
    TextView ferror,lerror,eerror,perror;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        fname = findViewById(R.id.signup_fname);
        lname = findViewById(R.id.signup_lname);
        email = findViewById(R.id.signup_email);
        password = findViewById(R.id.signup_password);
        gender = findViewById(R.id.signup_gender);
        branch = findViewById(R.id.signup_branch);
        signup = findViewById(R.id.submit);

        ferror = findViewById(R.id.fname_error);
        lerror = findViewById(R.id.lname_error);
        eerror = findViewById(R.id.email_error);
        perror = findViewById(R.id.password_error);
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Boolean Fname = fname.getText().toString().trim().isEmpty();
                Boolean Lname = lname.getText().toString().trim().isEmpty();
                String Email = email.getText().toString().trim();
                Boolean Email_val = email.getText().toString().trim().isEmpty();
                String Password = password.getText().toString().trim();
                Boolean Password_val = password.getText().toString().trim().isEmpty();
                Boolean Branch = branch.isChecked();
                int id = gender.getCheckedRadioButtonId();
                Gender = findViewById(id);
                if(!Fname && !Lname && !Email_val && !Password_val && Patterns.EMAIL_ADDRESS.matcher(Email).matches() && Password.length()>=8){
                    fname.setBackgroundResource(R.drawable.valid_border);
                    lname.setBackgroundResource(R.drawable.valid_border);
                    email.setBackgroundResource(R.drawable.valid_border);
                    password.setBackgroundResource(R.drawable.valid_border);
                    branch.setBackgroundResource(R.drawable.valid_border);
                    gender.setBackgroundResource(R.drawable.valid_border);
                    Intent intent = new Intent(Signup.this,Welcome.class);
                    intent.putExtra("fname",fname.getText().toString().trim());
                    intent.putExtra("lname",lname.getText().toString().trim());
                    intent.putExtra("email",email.getText().toString().trim());
                    intent.putExtra("password",password.getText().toString().trim());
                    intent.putExtra("gender",Gender.getText().toString());
                    intent.putExtra("branch",branch.isChecked());
                    Toast.makeText(Signup.this,"Valid Credentials...",Toast.LENGTH_SHORT).show();
                    startActivity(intent);
                }
                else {
                    if(Fname){
                        ferror.setText("Name is Required");
                        ferror.setVisibility(View.VISIBLE);
                        fname.setBackgroundResource(R.drawable.invalid_border);
                    }
                    else{
                        ferror.setVisibility(View.GONE);
                        fname.setBackgroundResource(R.drawable.valid_border);
                    }
                    if(Lname){
                        lerror.setText("Surname is Required");
                        lerror.setVisibility(View.VISIBLE);
                        lname.setBackgroundResource(R.drawable.invalid_border);
                    }
                    else{
                        lerror.setVisibility(View.GONE);
                        lname.setBackgroundResource(R.drawable.valid_border);
                    }
                    if(Email_val){
                        eerror.setText("Email is Required");
                        eerror.setVisibility(View.VISIBLE);
                        email.setBackgroundResource(R.drawable.invalid_border);
                    }
                    else{
                        if(Patterns.EMAIL_ADDRESS.matcher(Email).matches()){
                            eerror.setVisibility(View.GONE);
                            email.setBackgroundResource(R.drawable.valid_border);
                        }
                        else{
                            eerror.setText("Email is Invalid");
                            eerror.setVisibility(View.VISIBLE);
                            email.setBackgroundResource(R.drawable.invalid_border);
                        }
                    }
                    if(Password_val){
                        perror.setText("Password is Required");
                        perror.setVisibility(View.VISIBLE);
                        password.setBackgroundResource(R.drawable.invalid_border);
                    }
                    else{
                        if(Password.length()>=8) {
                            perror.setText("Password to short");
                            perror.setVisibility(View.GONE);
                            password.setBackgroundResource(R.drawable.valid_border);
                        }
                        else{
                            perror.setVisibility(View.GONE);
                            password.setBackgroundResource(R.drawable.invalid_border);
                        }
                    }
                    branch.setBackgroundResource(R.drawable.valid_border);
                    gender.setBackgroundResource(R.drawable.valid_border);
                    Toast.makeText(Signup.this,"Invalid Credentials...",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}