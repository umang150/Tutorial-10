package com.example.tutorial05;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Welcome extends AppCompatActivity {
TextView welcome;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        Intent intent = getIntent();
        String fname = intent.getStringExtra("fname");
        String lname = intent.getStringExtra("lname");
        String email = intent.getStringExtra("email");
        String pass = intent.getStringExtra("password");
        String gender = intent.getStringExtra("gender");
        boolean branch = intent.getBooleanExtra("branch",false);
        String Branch = "";
        if(branch){
            Branch = "Branch CE/IT";
        }
        welcome = findViewById(R.id.welcome_text);
        welcome.setText(fname+"\n"+lname+"\n"+email+"\n"+pass+"\n"+gender+"\n"+Branch);
    }
}